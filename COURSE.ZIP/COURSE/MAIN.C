#define MAIN
#include "core.h"

int main(){
	
	interface();
	return 0;
}